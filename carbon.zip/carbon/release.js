module.exports = require('now-release')
